-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2018 at 10:50 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bolt`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(15) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_desc` varchar(255) NOT NULL,
  `price` int(10) NOT NULL,
  `units` int(5) NOT NULL,
  `total` int(15) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `product_code`, `product_name`, `product_desc`, `price`, `units`, `total`, `date`, `email`) VALUES
(38, '902', 'combiflam', 'stomach', 45, 1, 45, '2018-11-24 09:22:28', 'chiragb@gmail.com'),
(39, '902', 'combiflam', 'stomach', 45, 1, 45, '2018-11-24 09:23:24', 'chiragb@gmail.com'),
(40, '903', 'volini', 'pain', 40, 6, 240, '2018-11-24 09:24:55', 'chiragb@gmail.com'),
(41, '45678', 'combiflam', 'health', 50, 5, 250, '2018-11-24 09:28:42', 'chiragb@gmail.com'),
(42, '904', 'glycomet', 'leg', 45, 1, 45, '2018-11-24 09:30:43', 'chiragb@gmail.com'),
(43, '904', 'glycomet', 'leg', 45, 1, 45, '2018-11-24 09:47:35', 'chiragb@gmail.com'),
(44, '12345', 'Disprin', 'headache', 19, 2, 38, '2018-11-24 09:47:35', 'chiragb@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `product_img_name` varchar(50) DEFAULT NULL,
  `product_code` int(11) DEFAULT NULL,
  `product_desc` varchar(500) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_img_name`, `product_code`, `product_desc`, `qty`, `price`) VALUES
(1, 'Disprin', 'disprin', 12345, 'headache', 10, 19),
(4, 'volini', 'volini', 903, 'pain', 14, 40),
(5, 'glycomet', 'glycomet', 904, 'leg', 28, 45),
(6, 'betadine', 'betadine', 905, 'yyyyy', 20, 50),
(7, 'aspirine', 'sdds', 906, 'ydyyyy', 3, 55),
(8, 'adalimunab', 'sdds', 907, 'yddyyyy', 15, 54),
(9, 'rexcough', 'sddds', 908, 'ydddyyyy', 10, 50),
(10, 'multivitamin', 'sdddds', 909, 'yddddyyyy', 12, 45),
(11, 'torex_cough_syrup', 'sddddds', 910, 'ydddddyyyy', 5, 20),
(12, 'crocin', 'sdddddss', 911, 'ydddddydyyy', 6, 30),
(13, 'paracetamol', 'sdddddsds', 912, 'ydddddydydyy', 7, 35),
(14, 'isotretinoine', 'sdddddsdsd', 913, 'ydddddydydydy', 8, 28),
(15, 'cinarest', 'sdddddsdsds', 914, 'y9dddddydydydy', 10, 29),
(999, 'combiflam', 'combi', 45678, 'health', 15, 50);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pin` int(6) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `fname`, `lname`, `address`, `city`, `pin`, `type`) VALUES
(1, 'subrattrivedi@gmail.com', 'subrat', 'Subrat', 'Trivedi', 'DTU CAMPUS ROHINI', 'solan', 201301, 'user'),
(2, 'chiragb@gmail.com', '123456789', 'chirag', 'bhatti', 'deonghat', 'solan', 173212, ''),
(3, 'bhattichirag@gmail.com', '123456789', 'tyty', 'lyster', 'noida', 'Delhi', 123456, ''),
(4, 'kunalk@gmail.com', '123456789', 'kunal', 'k', 'noida', 'noida', 123412, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
