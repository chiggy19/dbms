<?php

if(session_id() == '' || !isset($_SESSION)){session_start();}

?>

<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MEDSTORE</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>

    <link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
  <link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/responsive.css">


    <!-- Products -->

		
  </head>
  <body>

    <nav class="top-bar" data-topbar role="navigation">
      <ul class="title-area">
        <li class="name">
          <h1><a href="index.php">MEDSTORE</a></h1>
        </li>
        <li class="toggle-topbar menu-icon"><a href="#"><span></span></a></li>
      </ul>

      <section class="top-bar-section">
        <ul class="right">
				<li><a href="about.php">About</a></li>
        <li><a href="products.php">Medicines</a></li>
        <li><a href="cart.php">View Cart</a></li>
        <li><a href="orders.php">My Medicines</a></li>
        <li><a href="contact.php">Contact Us</a></li>
          <?php

          if(isset($_SESSION['username'])){
            echo '<li><a href="account.php">My Account</a></li>';
            echo '<li><a href="logout.php">Log Out</a></li>';
          }
          else{
            echo '<li><a href="login.php">Log In</a></li>';
            echo '<li><a href="register.php">Register</a></li>';
          }
          ?>
        </ul>
      </section>
    </nav>

    

    <center> 
    <img src="images/mobile.jpg">
	</center>
	<div class="container">
			<div class="row">
				<div class="col">
					
					<div class="product_grid">

					<!-- Product -->
					<div class="product">
							<div class="product_image"><img src="images/download.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">Disprin</a></div>
								<div class="product_price">Rs.19</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/b2275b3701c4e5810786a4fb9f3c9840bc40a9481.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">Combiflam</a></div>
								<div class="product_price">Rs.50</div>
							</div>
						</div>

							<!-- Product -->
							<div class="product">
							<div class="product_image"><img src="images/volini-spray-500x500.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">volini</a></div>
								<div class="product_price">Rs.70</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/360738.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">GLycomet</a></div>
								<div class="product_price">Rs.50</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/productagradi-44419871.7667a4.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">Betadine</a></div>
								<div class="product_price">Rs.70</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/Aspirin-325-mg---Compares-to-Bayer-559510-MEDIUM_IMAGE.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">Aspirine</a></div>
								<div class="product_price">RS.30</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/AbbVie_Humira_adalimumab.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">Adalimunab</a></div>
								<div class="product_price">Rs.50</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/cough-3.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">rexcough syrup</a></div>
								<div class="product_price">Rs.80</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/multivitamins-tablets-500x500.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">Multivitamin</a></div>
								<div class="product_price">Rs.250</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/download (1).jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">torex cough syrup</a></div>
								<div class="product_price">Rs.110</div>
							</div>
						</div>
						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/CROCIN-1409821292-10015831.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">Crocin</a></div>
								<div class="product_price">Rs.20</div>
							</div>
						</div>
							<!-- Product -->
								<div class="product">
							<div class="product_image"><img src="images/paracetamol-tablets-500x500.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">Paracetamol</a></div>
								<div class="product_price">Rs.19</div>
							</div>
						</div>
						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/SUDAFED-TABLETS-X12-160812.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">Isotretinoine</a></div>
								<div class="product_price">Rs.250</div>
							</div>
						</div>

						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="images/sinarest-af-syrup-500x500.jpg" alt=""></div>
							<br>
							<div class="product_content">
								<div class="product_title"><a href="product.html">cinarest</a></div>
								<div class="product_price">RS.50</div>
							</div>
						</div>

					</div>
						
				</div>
			</div>
		</div>
	</div>

    <div class="row" style="margin-top:10px;">
      <div class="small-12">

        <footer style="margin-top:10px;">
           <p style="text-align:center; font-size:0.8em;">&copy; MEDSTORE. All Rights Reserved.</p>
        </footer>

      </div>
    </div>





    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>



      <script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/Isotope/isotope.pkgd.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/custom.js"></script>


  </body>
</html>
